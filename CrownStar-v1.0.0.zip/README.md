# CrownStar – 企业级主权 AI 私有化平台

CrownStar 是深度集成 DeepSeek 的企业级主权 AI 私有化平台，支持离线部署与国产化环境，确保数据不出域、模型自主可控，助力中国企业在合规框架下高效落地 AI。

## 🎯 核心价值

- **主权 AI** – 数据不出企业网络，完全自主掌控
- **DeepSeek 原生集成** – 踩在中国 AI 最大生态上
- **私有化部署** – 支持离线运行，满足信创要求
- **企业级就绪** – JWT 认证、RBAC、审计日志、限流
- **开箱即用** – 提供 Docker 和 SQLite 快速启动

## 🚀 快速体验（5 分钟）

### 使用 Docker（推荐）
\\\ash
docker run -p 8000:8000 -e DEEPSEEK_API_KEY=sk-... crownstar/crownstar:latest
\\\

### 使用 Python 源码
\\\ash
git clone https://gitee.com/st3vensben/crown-star-ai-bot.git
cd crown-star-ai-bot
# 运行安装脚本 (Windows)
install.bat
# 或手动:
# python -m venv venv && venv\Scripts\activate
# pip install -r requirements.txt
# cp .env.example .env  # 填入你的 DeepSeek API Key
# python scripts/init_db.py
# uvicorn app.main:app --host 0.0.0.0 --port 8000
\\\

访问 http://localhost:8000/api/docs 查看 API 文档。

## 📊 适用场景

- 政府 / 央企：数据安全、信创合规
- 金融 / 保险：隐私保护、审计追溯
- 医疗：患者数据不出院
- 制造：核心工艺数据私有化

## 🔒 商业授权

CrownStar 是专有商业软件，提供企业级私有化部署版本。  
如需采购、定制或渠道合作，请联系：**st3vens.ben@yandex.com**

## 📦 下载试用

请访问 [Releases](https://gitee.com/st3vensben/crown-star-ai-bot/releases) 下载最新稳定版安装包（含一键安装脚本）。

## 📄 文档

[完整部署文档](https://gitee.com/st3vensben/crown-star-ai-bot/wiki) | [API 参考](http://localhost:8000/api/docs)
